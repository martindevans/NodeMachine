﻿
namespace NodeMachinePluginTemplate
{
    class EntryPoint
    {
        public static void Main(string[] args)
        {
        }
    }
}
